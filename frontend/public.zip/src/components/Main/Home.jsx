import React from 'react'
import AppDrawer from './AppDrawer'

const Home = () => {
  return (
    <div>
        <AppDrawer/>
    </div>
  )
}

export default Home